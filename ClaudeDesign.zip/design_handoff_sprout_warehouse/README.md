# Handoff: Sprout Warehouse — Warehouse MVP UI

## Overview
Web app for events-equipment warehouse tracking (serialized items, work orders, purchase orders, returns, missing/damaged items). RTL Arabic-first UI for Egyptian events production companies. This package covers the **core flow**: Login, Dashboard, Product Types, Serialized Items, Work Orders (create/fulfill/return/close), Missing Items. Boxes, Purchase Orders, Damage Reports, Maintenance Orders, Transaction Log, and Settings are stubbed as "coming soon" placeholders in the nav and are not yet designed.

## About the Design Files
The file `Sprout Warehouse.dc.html` is a **design reference / interactive prototype** built in HTML, not production code. It demonstrates layout, states, copy, and interaction flow. Recreate this UI in the target codebase's existing framework and component library (or choose an appropriate stack if none exists yet) — do not embed or copy the HTML/JS directly into production.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and copy are final/near-final for the core flow. Treat hex values and type sizes below as authoritative.

## Global Design Tokens

**Colors**
- Primary (sidebar, primary buttons, headers): `#1B3A2D` (dark forest green)
- Accent (success, active links, highlights): `#5DB848` (leaf green)
- Background: `#F4F7FB`
- Surface/card: `#FFFFFF`
- Error/warning: `#DC2626`
- Text primary: `#1B3A2D`
- Text muted: `#64748B`
- Border/divider: `#E2E8F0`

**Status badge colors**
- available → bg `#ECFDF3` / text `#15803D`
- out → bg `#EFF6FF` / text `#1D4ED8`
- damaged → bg `#FFF7ED` / text `#C2410C`
- missing → bg `#FEF2F2` / text `#B91C1C`
- in_maintenance → bg `#F5F3FF` / text `#6D28D9`
- written_off → bg `#F1F5F9` / text `#475569`

**Work Order status colors**
- draft → gray `#F1F5F9`/`#475569`
- in_progress → blue `#EFF6FF`/`#1D4ED8`
- fulfilled → teal `#F0FDFA`/`#0F766E`
- partially_returned → orange `#FFF7ED`/`#C2410C`
- returned → green `#ECFDF3`/`#15803D`
- closed → dark gray `#F1F5F9`/`#334155`

**Typography**
- Font: Cairo (Google Fonts), weights 400/500/600/700/800
- Direction: RTL throughout; nav/headers/badges show Arabic + English in parentheses, forms/tables are Arabic-only
- Page titles: 22px/800; section titles: 15px/700; body/table text: 13.5px; muted meta text: 12–13px

**Layout**
- Fixed right sidebar: 240px wide, dark green `#1B3A2D`, full height
- Main content: flexible width, 28px/32px padding
- Cards: white surface, 1px `#E2E8F0` border, 10px border-radius
- Scan inputs: 2px `#5DB848` border, large 16–18px bold text, always auto-focused

## Screens

### 1. Login
- Centered card (380px) on dark green gradient background
- Sprout logo mark + "Sprout Warehouse" + tagline "وقّف ضياع المعدات"
- Email + password fields, RTL
- Error state: red banner "البريد الإلكتروني أو كلمة المرور غير صحيحة" if fields empty on submit

### 2. Sidebar (persistent, all screens)
- Sprout logo top
- Client company logo placeholder (dashed border box, editable, sits below Sprout logo)
- Nav groups: الرئيسية (Dashboard) / الكتالوج (Product Types, Serialized Items, Boxes*) / المعاملات (Purchase Orders*, Work Orders) / التقارير (Missing Items, Damage Reports*, Maintenance Orders*, Transaction Log*) / الإعدادات*
  (*= placeholder screen only)
- Active nav item: white text on `rgba(255,255,255,0.12)` background
- Bottom: user name + role + logout link

### 3. Dashboard
- 5 summary cards: Total / Available / Out / Damaged / Missing, each with a colored top border matching its status color
- Quick actions: "New Work Order", "Receive Stock"
- Stock-by-type table with: category filter dropdown, name search input, manual refresh button
- Table columns: Type | Category | Total | Available | Out | Damaged | Missing
- Row click → navigates to Serialized Items filtered by that type

### 4. Product Types
- Table: Name | Model Code | Total | Available | Status (active/archived) | Actions (archive/unarchive)
- "New Product Type" button toggles an inline form (Name*, Model Code, Description) with required-field validation

### 5. Serialized Items
- Filter by product type dropdown + serial search
- Table: Serial Number | Product Type | Status badge | Last WO reference | Print QR action
- "Register New Item" toggles inline form: product type selector + auto-focused serial input; duplicate-serial error state; success flash message
- Print QR modal: placeholder QR block + serial + product type, Print button
- Empty state message guides to register/adjust filter

### 6. Work Orders — List
- Status tabs: All / Draft / In Progress / Fulfilled / Returned / Closed
- Table: Reference | Job Name | Client | Date Out | Status | Open action
- Primary WOs show nested supplementary WOs indented beneath (↳ prefix), own status badge and Open action
- "New Work Order" inline form: Job Name*, Client, Date Out*, dynamic line items (product type + qty, add/remove rows)

### 7. Work Order Detail — Fulfillment (in_progress)
- Header: WO ref, job, client, date, status badge
- Overall progress bar (scanned/requested)
- Large auto-focused scan input + Scan button; Enter key submits
- Inline error banner (red) with specific messages, e.g. serial not found, wrong status, wrong product type for this WO, quantity already met
- Inline success banner (green) on valid scan
- Per-line-item progress bars (product type: scanned/requested)
- Session-scanned list (checkmark + serial + type)
- "Generate Packing List PDF" (stub) always available; "Confirm Fulfillment" disabled until fully scanned

### 8. Work Order Detail — Other statuses (fulfilled/partially_returned/returned/closed)
- Header same as above
- Line items table: Type | Requested | Returned | Damaged | Missing
- Actions: "Process Return" (fulfilled/partially_returned only), "Transfer Item" (stub, shows explanatory note), "Close Work Order" (fulfilled/partially_returned only, red outline), "Generate PDF" (stub)

### 9. Return Screen
- WO header (read-only) + running progress label
- Auto-focused scan input + "Mark as Damaged" checkbox toggle
- Two-column result lists: "Returned" (green, ✓/⚠ icon) and "Still Out" (orange/red)
- Inline error banner for invalid/mismatched scans
- "End Return Session" → summary modal (Returned / Damaged / Still Missing counts) → WO status auto-updates to returned or partially_returned

### 10. Close Work Order (modal)
- Warning banner listing serials still out that will become "Missing"
- Cancel / Close Work Order (red) buttons

### 11. Missing Items
- Table: Serial | Product Type | Linked WO | Date Missing | Status badge | Actions
- Row actions (only when status=missing): "Mark as Found" (opens modal w/ optional note, restores to available), "Write Off" (confirmation modal, red, sets written_off)
- Empty state explains items appear here automatically when a WO closes with items still out

### 12. Coming-soon placeholder
- Used for Boxes, Purchase Orders, Damage Reports, Maintenance Orders, Transaction Log, Settings
- Centered icon block + screen name + "will be added in a future build" message

## Interactions & Behavior
- All scan inputs are auto-focused and submit on Enter or button click
- Validation errors are always specific (include the serial number and the reason/location), never generic
- Confirmation modals gate irreversible actions: Close WO, Write Off
- Status changes cascade: fulfilling scans an item → item status "out"; returning → "available" or "damaged"; closing with items still out → those items become "missing"
- Dashboard row click carries a filter into Serialized Items (cross-screen state)

## State Management (reference implementation used in the prototype)
- `productTypes[]` — id, name, modelCode, category, archived
- `serializedItems[]` — id, serial, productTypeId, status (available/out/damaged/missing/written_off), lastWO
- `workOrders[]` — ref, job, client, dateOut, status, supplementaryOf, lineItems[{productTypeId, requested, scanned, returned, damaged, missing}], scannedSession[]
- Screen state: current screen key, active WO ref, form field values, modal key, transient success/error strings
- All mutations are local/in-memory in the prototype; a real backend should persist these and emit the same status transitions

## Assets
No external image assets. Sprout logo is a simple circular mark placeholder (dark green rounded square + green circle) — replace with real brand SVG/logo files in production. QR codes are rendered as a placeholder checkerboard block — replace with a real QR-generation library.

## Files
- `Sprout Warehouse.dc.html` — full interactive prototype (open directly in a browser)
